/**
 * Slicer
 * A library for slicing geometry, well, into slices.
 * http://github.com/OffenesFeld/Slicer
 *
 * Copyright (C) 2013 FELD http://feld.is
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 *
 * @author      FELD http://feld.is
 * @modified    06/18/2013
 * @version     0.1b (1)
 */

package is.feld.slicer;


public class LineSegment2D {
  public final Point2D start;
  public final Point2D end;


  public LineSegment2D(Point2D theStart, Point2D theEnd) {
    start = theStart;
    end = theEnd;
  }


  public LineSegment2D(LineSegment2D theS) {
    start = new Point2D(theS.start);
    end = new Point2D(theS.end);
  }

}

